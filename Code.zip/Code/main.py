import os
import time
import random
import torch
import transformers
import torch
from torch import tensor
from tqdm import tqdm
from transformers import AutoModel, AutoTokenizer
import shutil

from data.CodeBert_process import slice_process, code_to_tensor


def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.

if __name__ == '__main__':
    path = "D:\\Master_Project\\TData1\\encode"
    files = os.listdir(path)
    for file in tqdm(files):
        random1 = random.randint(1,10)
        if(random1<=7):
            shutil.copy("D:\\Master_Project\\TData1\\encode\\"+file,"D:\\Master_Project\\SARD_Train\\encode\\"+file)
            shutil.copy("D:\\Master_Project\\TData1\\label\\"+file,"D:\\Master_Project\\SARD_Train\\lable\\"+file)
        else:
            shutil.copy("D:\\Master_Project\\TData1\\encode\\" + file,"D:\\Master_Project\\SARD_Test\\encode\\" + file)
            shutil.copy("D:\\Master_Project\\TData1\\label\\" + file, "D:\\Master_Project\\SARD_Test\\lable\\" + file)




# See PyCharm help at https://www.jetbrains.com/help/pycharm/


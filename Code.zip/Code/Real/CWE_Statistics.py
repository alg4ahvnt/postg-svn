# 开发时间 2024/3/19 16:42
import os
import torch
from tqdm import tqdm
from torch import nn

def statistics_CWE_info():
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    test_torch_path = "D:\\kyk\\Experiment\\OPENSSL Result\\Data\\Test\\Torch"
    test_label_path = "D:\\kyk\\Experiment\\OPENSSL Result\\Data\\Test\\Label"
    model = torch.load("D:\\kyk\\Experiment\\OPENSSL Result\\0308.pt")
    cwe_list = []
    cwe_tp = []
    cwe_fn = []
    flag = False
    for file in tqdm(os.listdir(test_torch_path)):
        torch1 = torch.load(test_torch_path+"\\"+file).unsqueeze(0).to(device)
        result1 = model(torch1).squeeze(0)
        label1 = torch.load(test_label_path+"\\"+file).to(device)
        pj = file.split("_")[0]
        cwe = extract_CWE(pj)

        for i in range(20):
            if label1[i] == 1:
                flag = True
                if cwe not in cwe_list:
                    cwe_list.append(cwe)
                    cwe_tp.append(0)
                    cwe_fn.append(0)
                index = cwe_list.index(cwe)
                if torch.equal(torch.argmax(result1[i]),torch.tensor(0).to(device)):
                #if torch.argmax(result1[i]) == torch(0).to(device):
                    cwe_fn[index] = cwe_fn[index]+1
                else:
                    cwe_tp[index] = cwe_tp[index]+1
    print("CWE-ID     TP   FN    Recall")
    for i in range(len(cwe_list)):
        print(cwe_list[i]+"    "+str(cwe_tp[i])+"    "+str(cwe_fn[i])+"    "+str(round(cwe_tp[i]/(cwe_tp[i]+cwe_fn[i]),6)))

def extract_CWE(pj_path):
    cwe_path = "D:\\Master_Project\\OPENSSL\\OPENSSL_origin\\"+pj_path+"-v1.0.0\\manifest.txt"
    with open(cwe_path,'r') as f1:
        lines = f1.readlines()
        for line in lines:
            if "CWE-" in line:
                return line.split("\"")[-2]
    f1.close()
def rename_sarif():
    path = "D:\\kyk\\Experiment\\POUSE Result\\POUSE_Origin"
    for pj in tqdm(os.listdir(path)):
        pj_path = path+"\\"+pj
        for file in os.listdir(pj_path):
            if file.endswith(".sarif"):
                os.rename(pj_path+"\\"+file,pj_path+"\\"+file.split(".")[0]+".txt")
if __name__ == "__main__":
    statistics_CWE_info()
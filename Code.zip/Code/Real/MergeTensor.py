# 开发时间 2023/10/26 14:19
import os

import torch
from tqdm import tqdm


def merge():
    path = "D:\\Master_Project\\0217\\Torch"
    files = os.listdir(path)
    for file in tqdm(files):
        list = file.split("_")
        old_encode = torch.load("D:\\Master_Project\\0217\\Torch\\" + file)
        old_label = torch.load("D:\\Master_Project\\0217\\Label\\" + file)
        if list[-1] != "0.pth":
            continue
        else:
            i = 1
            while (list[0]+"_"+list[1]+"_"+str(i)+".pth") in files:
                str1 = list[0]+"_"+list[1]+"_"+str(i)+".pth"

                encode2 = torch.load("D:\\Master_Project\\0217\\Torch\\" + str1)
                label2 = torch.load("D:\\Master_Project\\0217\\Label\\" + str1)
                old_encode,old_label = mergeTwoTensor(file,old_encode,old_label,encode2,label2)
                i += 1
            write_tensor(file,old_encode,old_label)

def mergeTwoTensor(file_name,encode1,label1,encode2,label2):
    list_label=[]
    list_encode = []
    while (encode1.size(0) < 20):
        encode1 = torch.cat((encode1, torch.zeros([1, 768])), dim=0)
        label1 = torch.cat((label1, torch.tensor([0])), dim=0)
    for i in range(20):
        if not torch.equal(encode1[i],torch.zeros([768])):
            list_encode.append(encode1[i])
            list_label.append(label1[i])
    for i in range(20):
        if not torch.equal(encode2[i],torch.zeros([768])):
            list_encode.append(encode2[i])
            list_label.append(label2[i])
    assert len(list_encode) == len(list_label)
    if len(list_encode) <= 20:
        for i in range(20-len(list_encode)):
            list_encode.append(torch.zeros([768]))
            list_label.append(torch.tensor(0))
        merged_encode = torch.stack(list_encode)
        merged_label = torch.stack(list_label)
        return merged_encode,merged_label
    else:
        merged_encode = torch.stack(list_encode)
        merged_label = torch.stack(list_label)
        write_tensor(file_name,merged_encode[0:20],merged_label[0:20])
        return merged_encode[20:],merged_label[20:]

def write_tensor(file_name,encode,label):
    path = "D:\\Master_Project\\All_Data_Merge"
    list = file_name.split("_")
    newStr = list[0]+"_"+list[1]+"_Merge"
    print(newStr)
    num = 0
    for file in os.listdir(path+"\\Encode"):
        if(file.startswith(newStr)):
            num+=1
    num+=1
    while(encode.size(0)<20):
        encode = torch.cat((encode, torch.zeros([1, 768])), dim=0)
        label = torch.cat((label,torch.tensor([0])),dim = 0)
    torch.save(encode,path+"\\Encode\\"+newStr+str(num)+".pth")
    torch.save(label, path + "\\Label\\" + newStr + str(num) + ".pth")


if __name__ =="__main__":
    merge()









# 开发时间 2023/11/2 9:49
import os
import random
import shutil
import torch.utils.data as Data
import torch
from gensim.models import KeyedVectors,word2vec,Word2Vec
from torch import nn
from tqdm import tqdm
from data.Encoder import BiLSTM, BiLSTM_Attention, BiGRU, Code_NN, TModel
from transformers import AutoTokenizer, AutoModel
class SDataSet(torch.utils.data.Dataset):
    def __init__(self,train=True):
        self.train = train
        self.tensor_list = []
        self.label_list = []
        if train:
            self.path = "D:\\kyk\\torch\\Train\\"
        else:
            self.path = "D:\\kyk\\torch\\Test\\"
        encode_path = self.path + "Encode"
        label_path = self.path + "Label"
        encode_files = os.listdir(encode_path)
        print("Data Loading......")
        count = 0
        for file in tqdm(encode_files):
            count+=1
            if(count==26033):
                break

            self.tensor_list.append(torch.load(encode_path+"\\"+file)[0:12]) #15,768
            self.label_list.append(torch.load(label_path+"\\"+file)[0:12])
        print("Done.")
    def __len__(self):
        return len(self.tensor_list)
    def __getitem__(self,idx):
        return self.tensor_list[idx],self.label_list[idx]



def cb_Process():
    print('loading model...')
    tokenizer = AutoTokenizer.from_pretrained("C:\\Users\\柯晔坤\\codebert-base")
    model = AutoModel.from_pretrained("C:\\Users\\柯晔坤\\codebert-base")
    path = "D:\\kyk\\Test"
    for file in tqdm(os.listdir(path)):
        print("Processing:  "+file)
        str = ""
        with open(path+"\\"+file,'r') as f1:
            lines = f1.readlines()
            slice_len = len(lines)
            tagList = []
            for line in lines:
                tag = line.rstrip().split(" ")[-1]
                list = line.rstrip().split(" ")
                list.pop()
                list.pop()
                if (tag == "P"):
                    tagList.append(1)
                else:
                    tagList.append(0)
                for item in list:
                    str = str+item+" "
                str = str+"\n"
        f1.close()
        SC_tokens = tokenizer.tokenize(str)
        print(SC_tokens)
        tokens = [tokenizer.cls_token] + SC_tokens + [tokenizer.eos_token]
        if len(tokens) > 514:
            continue
        tokens_id = tokenizer.convert_tokens_to_ids(tokens)
        tokens_tensor = torch.tensor(tokens_id)[None, :]
        with torch.no_grad():
            try:
                results = model(tokens_tensor)
            except RuntimeError as exception:
                if "out of memory" in str(exception):
                    print('WARNING: out of memory')
                if hasattr(torch.cuda, 'empty_cache'):
                    torch.cuda.empty_cache()
        hidden_states_results = results.last_hidden_state
        line_hidden_states = []
        line_tmp_tensor = torch.zeros((768))
        token_count = 0
        for index in range(len(tokens_id)):
            if index == 0: continue
            # 遇到 [SEP] or [EOS] 退出
            if tokens_id[index] == 2: break
            if ((token_count == 0) & (tokens_id[index] == 50118)): continue
            token_count += 1
            line_tmp_tensor = line_tmp_tensor + hidden_states_results[0][index]
            if tokens_id[index] == 50118:
                line_hidden_states.append(line_tmp_tensor / token_count)
                line_tmp_tensor = torch.zeros((768))
                token_count = 0
        for i in range(12-slice_len):
            line_hidden_states.append(torch.zeros(768))
            tagList.append(0)
        encode = torch.stack(line_hidden_states)
        label = torch.tensor(tagList)
        torch.save(encode,"D:\\kyk\\torch\\Test\\Encode\\"+file.split(".")[0]+".pth")
        torch.save(label,"D:\\kyk\\torch\\Test\\Label\\" + file.split(".")[0] + ".pth")


#截断 每个文件最多20行
def crop():
    path_train  = "D:\\kyk\\Train_slice"
    path_test = "D:\\kyk\\Test_slice"
    for file in tqdm(os.listdir(path_train)):
        with open(path_train+"\\"+file,'r') as f1:
            lines = f1.readlines()
            sourceEnd = 0
            for index in range(len(lines)):
                if "-----" in lines[index]:
                    sourceEnd = index
                    break
            new_lines = lines[1:sourceEnd]
            write_Slices(new_lines,train = True)
        f1.close()
    for file in tqdm(os.listdir(path_test)):
        with open(path_test+"\\"+file,'r') as f1:
            lines = f1.readlines()
            sourceEnd = 0
            for index in range(len(lines)):
                if "-----" in lines[index]:
                    sourceEnd = index
                    break
            new_lines = lines[1:sourceEnd]
            write_Slices(new_lines,train = False)
        f1.close()
def write_Slices(lines,train = True):
    _len = len(lines)
    slices_total_num = int((_len/12))+1
    if train:
        for i in range(slices_total_num):
            if i != slices_total_num-1:
                with open("D:\\kyk\\Train\\"+str(judgeNum())+".txt",'w') as f1:
                    for j in range(12):
                        f1.writelines(lines[i*12+j])
                f1.close()
            else:
                with open("D:\\kyk\\Train\\"+str(judgeNum())+".txt",'w') as f1:
                    for j in range(i*12,_len):
                        f1.writelines(lines[j])
                f1.close()
    else:
        for i in range(slices_total_num):
            if i != slices_total_num-1:
                with open("D:\\kyk\\Test\\"+str(judgeNum(train = False))+".txt",'w') as f1:
                    for j in range(12):
                        f1.writelines(lines[i*12+j])
                f1.close()
            else:
                with open("D:\\kyk\\Test\\"+str(judgeNum(train = False))+".txt",'w') as f1:
                    for j in range(i*12,_len):
                        f1.writelines(lines[j])
                f1.close()
#给训练、测试数据命名编号
def judgeNum(train = True):
    if train:
        files = os.listdir("D:\\kyk\\Train")
        return len(files)
    else:
        files = os.listdir("D:\\kyk\\Test")
        return len(files)
#7:3划分数据集
def split():
    path = "D:\\kyk\\SVN_1"
    for file in os.listdir(path):
        if random.random()>0.3:
            shutil.copy("D:\\kyk\\SVN_1\\"+file,"D:\\kyk\\Train_slice\\"+file)
        else:
            shutil.copy("D:\\kyk\\SVN_1\\" + file, "D:\\kyk\\Test_slice\\" + file)
#删除空文件：
def delete_none():
    path1 = "D:\\kyk\\Train"
    path2 = "D:\\kyk\\Test"
    for file in tqdm(os.listdir(path1)):
        tag = False
        with open(path1+"\\"+file,'r') as f1:
            lines = f1.readlines()
            if len(lines) == 0:
                tag = True
        f1.close()
        if tag:
            os.remove(path1+"\\"+file)
    for file in tqdm(os.listdir(path2)):
        tag = False
        with open(path2+"\\"+file,'r') as f1:
            lines = f1.readlines()
            if len(lines) == 0:
                tag = True
        f1.close()
        if tag:
            os.remove(path2+"\\"+file)
def train(data_loader = None,Epoch = 100,lr = 1e-4):
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    Model = torch.load("D:\\kyk\\BiGRU.pt")
    optimizer = torch.optim.Adam(Model.parameters(), lr=lr)
    for epoch in tqdm(range(Epoch)):
        train_loss = 0.0
        for i, (tensors, labels) in enumerate(data_loader):
            tensors = tensors.float().to(device)  # (16,12,768)
            labels = labels.long().to(device)  # (16,12)
            # optimizer.zero_grad()
            predictions = Model(tensors)  # (16,12,2)
            predictions_reshape = predictions.view(-1, 2)  # reshape:(16*12,2)
            labels_reshape = labels.view(-1)  # reshape:(16*15)
            loss_fn = nn.CrossEntropyLoss(reduction="none")
            losses = loss_fn(predictions_reshape, labels_reshape)
            losses = losses.view(16, 12)
            avg_losses = losses.mean(dim=1)
            optimizer.zero_grad()
            avg_losses.backward(torch.ones_like(avg_losses))
            optimizer.step()
            train_loss += avg_losses.mean()
        print("Epoch:   %3d,   Loss:    %.7f" % (epoch + 1, train_loss / (len(data_loader))))
        torch.save(Model, 'D:\\kyk\\BiGRU.pt')
def test(net):
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    path = "D:\\kyk\\torch\\Test\\Encode"
    label_path = "D:\\kyk\\torch\\Test\\Label"
    files = os.listdir(path)
    sm = nn.Softmax(dim = 2)
    True_Positive = 0
    False_Positive = 0
    True_Negative = 0
    False_Negative = 0

    for file in tqdm(files):
        tensor = torch.load(path+"\\"+file).unsqueeze(0).to(device) #(1,15,768)
        label = torch.load(label_path+"\\"+file)#(15)
        predicts = sm(net(tensor)) #(1,15,2)
        count = 0
        for i in range(12):
            if (not torch.equal(tensor[0][i], torch.zeros((768)).to(device))):
                count += 1
        for i in range(count):
            if(torch.equal(torch.argmax(predicts[0][i]),torch.tensor(1).to(device))):
                if(torch.equal(label[i],torch.tensor(1))):
                    True_Positive += 1
                elif(torch.equal(label[i],torch.tensor(0))):
                    False_Positive += 1
            elif(torch.equal(torch.argmax(predicts[0][i]),torch.tensor(0).to(device))):
                if (torch.equal(label[i],torch.tensor(1))):
                    False_Negative += 1
                elif(torch.equal(label[i],torch.tensor(0))):
                    True_Negative += 1
    print("TP:")
    print(True_Positive)
    print("FP:")
    print(False_Positive)
    print("TN:")
    print(True_Negative)
    print("FN:")
    print(False_Negative)
    print("precision:")
    pre = precision(True_Positive,False_Positive,True_Negative,False_Negative)
    print(pre)
    print("recall:")
    rec = recall(True_Positive,False_Positive,True_Negative,False_Negative)
    print(rec)
    f1 = 2*pre*rec/(pre+rec)
    print("F1:")
    print(f1)
    print("accuracy:")
    print(accuracy(True_Positive,False_Positive,True_Negative,False_Negative))
    print("FPR:")
    print(FPR(True_Positive,False_Positive,True_Negative,False_Negative))
    print("IOU:")
    print(IOU(True_Positive, False_Positive, True_Negative, False_Negative))
def recall(TP,FP,TN,FN):
    return round(TP/(TP+FN),7)
def precision(TP,FP,TN,FN):
    return round(TP/(TP+FP),7)
def accuracy(TP,FP,TN,FN):
    return round((TP+TN)/(TP+FP+TN+FN),7)
def FPR(TP,FP,TN,FN):
    return round(FP/(FP+TN),7)
def IOU(TP,FP,TN,FN):
    return round(TP/(TP+FN+FP),7)
if __name__ == "__main__":
    dataSet = SDataSet(train=True)
    train_Loader = Data.DataLoader(dataSet , batch_size=16 , shuffle = True,pin_memory = True)
    train(data_loader=train_Loader)
    test(torch.load("D:\\kyk\\BiGRU.pt"))

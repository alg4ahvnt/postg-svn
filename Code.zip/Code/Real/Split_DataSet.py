# 开发时间 2023/10/25 13:09
# 7:2:1 OPENSSL
import os
import shutil
import random

from tqdm import tqdm


def split():
    path = "F:\\kyk\\POUSE\\Torch"
    count=0
    for file in tqdm(os.listdir(path)):
        a = random.random()
        if a>0.3:
            shutil.move(path+"\\"+file,"D:\\kyk\\Experiment\\POUSE Result\\POUSE\\Train\\Torch\\"+file)
            shutil.move("F:\\kyk\\POUSE\\Label\\"+file,
                        "D:\\kyk\\Experiment\\POUSE Result\\POUSE\\Train\\Label\\"+file)
        elif a<0.1:
            shutil.move(path+"\\"+file,"D:\\kyk\\Experiment\\POUSE Result\\POUSE\\Valid\\Torch\\"+file)
            shutil.move("F:\\kyk\\POUSE\\Label\\" + file,
                        "D:\\kyk\\Experiment\\POUSE Result\\POUSE\\Valid\\Label\\" + file)
        else:
            shutil.move(path+"\\"+file,"D:\\kyk\\Experiment\\POUSE Result\\POUSE\\Test\\Torch\\"+file)
            shutil.move("F:\\kyk\\POUSE\\Label\\" + file,
                        "D:\\kyk\\Experiment\\POUSE Result\\POUSE\\Test\\Label\\" + file)
        count+=1
if __name__ == "__main__":
    split()
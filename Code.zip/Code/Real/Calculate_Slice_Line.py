# 开发时间 2024/2/26 19:49
import os
import re
import shutil
from torch import nn




from tqdm import tqdm
def extractC():
    path = "D:\\Master_Project\\OPENSSL\\OPENSSL_origin"
    count = 0
    for pj in os.listdir(path):
        print(pj)
        pj_path = path+"\\"+pj+"\\src\\crypto"
        if len(os.listdir(pj_path)) == 1:
            if os.listdir(pj_path)[0].endswith(".c"):
                shutil.move(pj_path+"\\"+os.listdir(pj_path)[0],"D:\\Master_Project\\OPENSSL\\OPENSSL_C\\"+pj+"_"+os.listdir(pj_path)[0])
                continue
            else:
                new_path = pj_path+"\\"+os.listdir(pj_path)[0]
                for file in os.listdir(new_path):
                    if file.endswith(".c"):
                        shutil.move(new_path+"\\"+file,"D:\\Master_Project\\OPENSSL\\OPENSSL_C\\"+pj+"_"+file)
        else:
            for file in os.listdir(pj_path):
                if file.endswith(".c"):
                    shutil.move(pj_path+"\\"+file,"D:\\Master_Project\\OPENSSL\\OPENSSL_C\\"+pj+"_"+file)

        # files =
        # for file in files:
        #     if file.endswith(".c"):
        #         shutil.move(pj_path+"\\"+file,"D:\\kyk\\Experiment\\SVN Result\\SVN_C\\"+pj+"_"+file)

def extract_func(file_path):
    with open(file_path,'r') as f1:
        lines = f1.readlines()
        func_count = 0
        line_count = 0
        flag = False
        for line in lines:
            if flag == True:
                line_count += 1
                if line=="}\n":
                    flag = False
            if line.endswith(")\n") | ((line.endswith("{\n")&(line.lstrip()!="{\n"))):
                if (("if" not in line)
                        &("do" not in line)
                        &("for" not in line)
                        &("switch" not in line)
                        &("while" not in line)
                        &("else" not in line)
                        &("struct" not in line)):
                    if line[0]!=" ":
                        flag = True
                        func_count+=1
    f1.close()
    return func_count,line_count
if __name__ == "__main__":
    #^\s*(static\s+)?[a-zA-Z_*]+\s+[a-zA-Z_]+\s*\([^)]*\)\s*\{
    func_count = 0
    line_count = 0
    for file in tqdm(os.listdir("D:\\Master_Project\\OPENSSL\\OPENSSL_C")):
        f,l =     extract_func("D:\\Master_Project\\OPENSSL\\OPENSSL_C\\"+file)
        func_count+=f
        line_count+=l
    print('openssl平均函数行数为：'+str(round(line_count/func_count,7)))
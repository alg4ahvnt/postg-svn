# 开发时间 2023/10/26 19:36
import os
import shutil

from tqdm import tqdm


def copySarify():
    path = "D:\\kyk\\po_use"
    pjs = os.listdir(path)
    for pj in pjs:
        print("Processing:  "+pj)
        files = os.listdir(path+"\\"+pj)
        for file in tqdm(files):
            if file.endswith(".sarif"):
                shutil.copy(path+"\\"+pj+"\\"+file,"D:\\kyk\\POUSE_Origin\\"+pj.split("-v1.0.0")[0]+"\\"+file)
def tag():
    path = "D:\\kyk\\POUSE_Origin"
    pjs = os.listdir(path)
    for pj in tqdm(pjs):
        print("D:\\Processing:  "+pj)
        files = os.listdir(path+"\\"+pj)
        startLine = 0
        endLine = 0
        for file in files:
            if file.endswith(".sarif"):
                with open(path+"\\"+pj+"\\"+file,'r') as f1:
                    lines = f1.readlines()
                    for line in lines:
                        if ("startLine" in line):
                            l = line.lstrip().rstrip().rstrip(",")
                            startLine = int(l.split(" ")[-1])
                        if ("endLine" in line):
                            l = line.lstrip().rstrip()
                            endLine = int(l.split(" ")[-1])
                f1.close()
        for file in files:
            if file.endswith("slices"):
                slices = os.listdir(path+"\\"+pj+"\\"+file)
                for slice in slices:
                    print("---------------------------------------------------------")
                    print(slice)
                    with open(path+"\\"+pj+"\\"+file+"\\"+slice,'r') as f1:
                        lines = f1.readlines()
                        str = slice.split(".")[0]+"_tag.txt"
                        with open(path+"\\"+pj+"\\"+file+"\\"+str,'w') as f2:
                            for line in lines:
                                if "-----------" in line:
                                    f2.writelines(line)
                                    continue
                                if line.rstrip().split(" ")[-1].isdigit():
                                    num = int(line.rstrip().split(" ")[-1])
                                    if (num >= startLine) & (num <= endLine):
                                        f2.writelines(line.rstrip() + " " + "P\n")
                                        print(line.rstrip() + " " + "P")
                                    else:
                                        f2.writelines(line.rstrip() + " " + "N\n")
                        f2.close()
                    f1.close()
def delete():
    path = "D:\\kyk\\po_use"
    path2 = "D:\\kyk\\POUSE_Origin"
    files1 = os.listdir(path)
    files2 = os.listdir(path2)
    for file in files1:
        if file.split("-v1.0.0")[0] not in files2:
            print("removing:" +file)
            shutil.move("D:\\kyk\\po_use\\"+file,"D:\\kyk\\Delete\\"+file)
if __name__ == "__main__":
    tag()
# 开发时间 2024/3/8 13:06
import os

from tqdm import tqdm

if __name__ == "__main__":
    path = "D:\\kyk\\SVN\\SVN_Origin"
    slice_Num = 0
    line_Num = 0
    longest_Num = -1

    for pkg in tqdm(os.listdir(path)):
        pkg_path = path+"\\"+pkg+"\\slices"

        for file in os.listdir(pkg_path):
            if file.endswith("_tag.txt"):
                with open(pkg_path+"\\"+file,'r') as f1:
                    lines = f1.readlines()
                    for line in lines:
                        if "/home/hit-sse" in line:
                            slice_Num+=1
                            tmp = 0
                        else:
                            if '------------------------' not in line:
                                line_Num+=1
                                tmp+=1
                f1.close()
                if tmp>longest_Num:
                    longest_Num = tmp
                tmp = 0

    print(line_Num)
    print(slice_Num)
    print("SVN平均行数："+str(round(line_Num/slice_Num,7)))
    print("最长："+str(longest_Num))



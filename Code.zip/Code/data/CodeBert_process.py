import os
import random
import shutil
import time

from torch import nn
from torch.autograd._functions import tensor
from tqdm import tqdm
from transformers import AutoTokenizer, AutoModel
import torch

# 针对每一行 删除代码的行号和标签
# 返回一个数组 第一个位置是处理之后的字符串 第二个位置是原来的行标签
def deleteNumAndTag(str):
    newStr = ''
    str = str.strip()
    list = str.split(' ')
    result = []
    tag = 0
    if (list[-1]!='P') & (list[-1]!='N'):
        result.append(newStr)
        result.append(0)
        return result
    tagNP = list.pop()
    if(tagNP == 'N'):
        tag = 0
    elif(tagNP == 'P'):
        tag = 1
    list.pop()

    for i in range(len(list)):
        if i == len(list)-1:
            newStr = newStr + list[i]
        else:
            newStr = newStr + list[i] + ' '
    newStr = newStr+"\n"
    result.append(newStr)
    result.append(tag)
    return result

def deleteACUselessInfo(line):
    list1  = line.split(" ")
    result_str = ""
    for index in range(len(list1)):
        item_list = list1[index].split("\t")
        if index != len(list1)-1:
            for item_index in range(len(item_list)):
                result_str = result_str + item_list[item_index] + " "
        else:
            for item_index in range(len(item_list)):
                if item_index == len(item_list)-1:
                    result_str = result_str + item_list[item_index]
                else:
                    result_str = result_str + item_list[item_index] + " "
    return result_str
#针对每一个slice 进行处理 输出 SCcode ACcode 每一行SCcode的标签
def slice_process(path):
    SC_code = ''
    SC_line_tag = []
    AC_code = ''
    with open(path, 'r') as f:
        lines = f.readlines()
        flag = False
        count = 0
        for line in lines:
            count+=1
            if ('---------------' in line):
                flag = True
                count = 0
                continue
            if (flag):
                if(count!=1):
                    line = deleteACUselessInfo(line)
                    AC_code = AC_code + line.strip(' ')
            else:
                if(count!=1):
                    line = deleteNumAndTag(line)
                    if(line[0]!=''):
                        SC_line_tag.append(line[1])
                    SC_code = SC_code + line[0]
    f.close()
    AC_code = AC_code.rstrip('\n')

    return SC_code,AC_code,SC_line_tag

def code_to_tensor(tokenizer,model,SC_code,AC_code):

    #获取源代码和汇编代码的Tokens
    SC_tokens = tokenizer.tokenize(SC_code)
    AC_tokens = tokenizer.tokenize(AC_code)
    #通过[SEP]拼接源代码和汇编代码Token

    tokens = [tokenizer.cls_token]+SC_tokens+[tokenizer.sep_token]+AC_tokens+[tokenizer.eos_token]
    if(len(tokens)>=512):
        tokens = tokens[0:511]+[tokenizer.eos_token]
    #如果长度大于512，截断
    #print(tokens)
    #line的结束Token id:50118
    tokens_id = tokenizer.convert_tokens_to_ids(tokens)
    tokens_tensor = torch.tensor(tokens_id)[None,:]
    with torch.no_grad():
        try:
            results = model(tokens_tensor)
        except RuntimeError as exception:
            if "out of memory" in str(exception):
                print('WARNING: out of memory')
            if hasattr(torch.cuda, 'empty_cache'):
                torch.cuda.empty_cache()


    hidden_states_results = results.last_hidden_state
    #获取slice中每一行源代码的hidden_states,用每一个Token的hidden_states作平均
    line_hidden_states = []
    line_tmp_tensor = torch.zeros((768))
    token_count = 0
    for index in range(len(tokens_id)):
        if index == 0: continue
        #遇到 [SEP] or [EOS] 退出
        if tokens_id[index] == 2: break
        if ((token_count == 0) & (tokens_id[index] == 50118)): continue
        token_count += 1
        line_tmp_tensor = line_tmp_tensor + hidden_states_results[0][index]
        if tokens_id[index] == 50118:
            line_hidden_states.append(line_tmp_tensor/token_count)
            line_tmp_tensor = torch.zeros((768))
            token_count = 0

    return line_hidden_states



if __name__ == "__main__":
    print('loading model...')
    tokenizer = AutoTokenizer.from_pretrained("C:\\Users\\柯晔坤\\codebert-base")
    added_token = ["rax", "mov", "push", "pop", "xchg", "cmp", "call", "lea", "movsx", "add", "adc", "sub", "sbb",
                   "cdqe", "sal", "test", "nop", "jmp", "pushf", "popf", "pusha", "popa", "lds", "les", "inc", "dec",
                   "mul", "imul", "neg", "div",
                   "idiv", "cbw", "cwd", "and", "or", "xor", "not", "shr", "shl", "sar", "sal", "ror", "rol", "rcr",
                   "rcl",
                   "clc", "stc", "cmc", "cld", "std", "jle", "jbe", "je", "movw", "js", "ja", "jg", "jne", 'jnb',
                   "iret", "jz", "al", "eax",
                   "edx", "edi", "esi", "rsi", "rbp", "rsp", "rcx", "rdx", "DWORD", "QWORD", "PTR", "BYTE", "OFFSET",
                   "FLAT", "XMMWORD",                  "movabs", "DWORD", "ret", "jns", "movzx", "PTR", "sete"]
    tokenizer.add_tokens(added_token)
    model = AutoModel.from_pretrained("C:\\Users\\柯晔坤\\codebert-base", added_token)
    # 添加词汇后重现变化大小
    model.resize_token_embeddings(len(tokenizer))
    print(len(added_token))
    # print('processing...')
    # path = "D:\\kyk\\Experiment\\SVN Result\\SVN_Processed"
    # for file in tqdm(os.listdir(path)):
    #     SC,AC,flag = slice_process(path+"\\"+file)
    #     tensor = code_to_tensor(tokenizer,model,SC,AC)
    #     len_tensor = len(tensor)
    #     if len_tensor>=21:
    #         print("-------------------------------------------------------------")
    #         print(file)
    #         print("-------------------------------------------------------------")
    #     for i in range(20-len_tensor):
    #         tensor.append(torch.zeros([768]))
    #         flag.append(0)
    #     slice_pre = torch.stack(tensor)
    #     flag_pre = torch.tensor(flag)
    #     torch.save(slice_pre,"D:\\kyk\\Experiment\\SVN Result\\Data\\Torch\\"+file.split(".")[0]+".pt")
    #     torch.save(flag_pre, "D:\\kyk\\Experiment\\SVN Result\\Data\\Label\\" + file.split(".")[0] + ".pt")
    #







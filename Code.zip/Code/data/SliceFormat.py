import os
import torch
import re
# 数据格式构造 每一个slice变成：
# [SCode,[ACodelist],N/P]
# 判断Slice是否有漏洞
def judgeSliceFlaw(SList):
    flag = False
    for line in SList:
        lineList = line.split(' ')
        if(lineList[-1] == 'P'):
            flag = True
        else:
            continue
    return flag
def process_Slice(slice_path):
    label = False
    SList = []
    AList = []
    print(slice_path)
    with open(slice_path,'r') as f:
        lines = f.readlines()
        flag = False
        for line in lines:
            if('---------------' in line):
                flag = True
                continue
            if(flag):
                AList.append(line.strip())
            else:
                SList.append(line.strip())
    f.close()
    label = judgeSliceFlaw(SList)
    Final_List = []

    for line in SList:
        new_item = []
        new_item.append(line)
        if(len(line.split(' '))<=1):
            continue
        if(not line.split(' ')[-2].isdigit()):
            continue
        lineNum = int(line.split(' ')[-2])
        A_item_List = []
        ct = 0
        for ALine in AList:
            ct+=1
            if(ct==1):
                continue
            compareNum = int(ALine.split(' ')[-1])
            if(lineNum == compareNum):
                A_item_List.append(ALine)
        new_item.append(A_item_List)
        new_item.append(line.split(' ')[-1])
        Final_List.append(new_item)
    Final_List = deleteSCNumAndTag(Final_List)
    Final_List = deleteACUselessInfo(Final_List)
    for item in Final_List:
        print(item)
    return Final_List,label
#删除源代码的行号和tag
def deleteSCNumAndTag(list):
    newlist = []
    #每一个Item是一个源代码语句，汇编代码语句列表，N\P
    ct = 0
    for lineItem in list:
        ct += 1
        if ct==1:
            continue
        else:
            newlineItem = []
            #源代码
            SCode = lineItem[0]
            SCodeList = SCode.split(' ')
            SCodeList.pop()
            SCodeList.pop()
            newSCode = ""
            for token in SCodeList:
                newSCode = newSCode+token+' '
            newlineItem.append(newSCode.rstrip())
            newlineItem.append(lineItem[1])
            newlineItem.append(lineItem[2])
            newlist.append(newlineItem)

    return newlist
#删除汇编代码不必要信息
def deleteACUselessInfo(list):
    newlist = []
    #每一个lineItem都是一个行列表
    for lineItem in list:
        newlineItem = []
        newlineItem.append(lineItem[0])
        newASCodeList = []
        ASCodeList = lineItem[1]
        for ASCode in ASCodeList:
            newASCode = processASCode(ASCode)
            newASCodeList.append(newASCode)
        newlineItem.append(newASCodeList)
        newlineItem.append(lineItem[2])
        newlist.append(newlineItem)
    return newlist
def processASCode(ASCode):
    ASCode = ASCode.replace('\t',' ')
    ASCodeList = ASCode.split(' ')
    finalList = []
    for item in ASCodeList:
        if(item != ''):
            finalList.append(item)
    finalStr = ''
    for i in range(3,len(finalList)-1):
        if(i == len(finalList)-2):
            finalStr = finalStr + finalList[i]
        else:
            finalStr = finalStr + finalList[i]+' '
    return finalStr







if __name__ == '__main__':
    process_Slice("D:\\Master_Project\\Sard_All_Function\\000000014_0.txt")
    #processASCode('  70 0074 488B4008 	mov	rax, QWORD PTR [rax+8]	# tmp90, MEM[(char * *)argv_4(D) + 8B] 47')
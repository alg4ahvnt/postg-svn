# 开发时间 2023/10/18 11:10
import os
import shutil

from tqdm import tqdm


def extractLineASM(pj_Path):
    pj_Path = pj_Path
    fs = os.listdir(pj_Path)
    path = ''
    for fss in fs:
        if fss.endswith('.c.asm'):
            path = fss
    path = pj_Path+"\\"+path
    dict_ASM={}
    list = []
    with open(path,'r') as f1:
        lines = f1.readlines()
        for line in lines:
            if(line.split(' ')[0]=='#'):
                if((len(line.split(' '))>=2 )&(line.split(' ')[1].split('/')[0]=='src')):
                    line_num = int(line.split(' ')[1].split(':')[-2])
                    list.append(line_num)
                    newDict = {line_num:lineToASM(path,line)}
                    dict_ASM.update(newDict)
    f1.close()
    return dict_ASM
def lineToASM(path,line1):
    list = []
    with open(path,'r') as f1:
        lines = f1.readlines()
        indexList = []
        for i in range(len(lines)):
            if lines[i] == line1:
                indexList.append(i)
        for item in indexList:
            for i in range(item+1,len(lines)):
                if (lines[i].split(' ')[0] != '#'):
                    list.append(lines[i].rstrip())
                else:
                    break
    f1.close()
    if(list[-1].startswith('.L')):
        list.pop()
    return list
#匹配源代码与汇编代码：
def mapping_S_To_A_AndWrite():
    path = "D:\\Master_Project\\SLICE_origin"
    pjs = os.listdir(path)

    for pj in tqdm(pjs):
        print("Processing:  "+pj)
        asm_dict = extractLineASM(path+"\\"+pj)
        slices_path = path+"\\"+pj+"\\slices"
        for slice in os.listdir(slices_path):
            if slice.endswith("_tagFlaw.txt"):
                with open(slices_path+"\\"+slice,'r') as f1:
                    lines = f1.readlines()
                    s_List = []
                    for line in lines:
                        if "---------------" in line:
                            write_New(pj,s_List,asm_dict)
                            s_List = []
                        else:
                            s_List.append(line)
                f1.close()
def write_New(pj_name,s_List,asm_dict):
    a_List = []
    for line in s_List:
        if line == s_List[0]:
            continue
        if line.rstrip().split(" ")[-2].isdigit():
            num = int(line.rstrip().split(" ")[-2])
            asm_line = asm_dict.get(num)
            if asm_line != None:
                for item in asm_line:
                    a_List.append(item)
    files = os.listdir("D:\\kyk\\POUSE_Processed")
    num = 0
    for file in files:
        if file.startswith(pj_name):
            num+=1
    with open("D:\\kyk\\POUSE_Processed\\"+pj_name+"_"+str(num+1)+".txt",'w') as f1:
        for source in s_List:
            f1.writelines(source)
        f1.writelines("---------------------------------------------------\n")
        for asm in a_List:
            f1.writelines(asm+"\n")
    f1.close()
def count():
    path = "D:\\kyk\\POUSE_Origin"
    count = 0
    pjs = os.listdir(path)
    for pj in tqdm(pjs):
        slices = os.listdir(path+"\\"+pj+"\\slices")
        for slice in slices:
            with open(path+"\\"+pj+"\\slices\\"+slice,'r') as f1:
                lines = f1.readlines()
                for line in lines:
                    if "---------------------" in line:
                        count+=1
            f1.close()
    print(count)
def test():
    path = "D:\\kyk\\POUSE_Origin"
    for pj in os.listdir(path):
        files = os.listdir(path+"\\"+pj)
        if len(files) != 3:
            print(pj)
if __name__ == '__main__':
    pass
    #mapping_S_To_A_AndWrite()
    # path = "D:\\Master_Project\\1018\\FFMPEG_slice"
    # for pj in tqdm(os.listdir(path)):
    #     print('Processing:   '+pj)
    #     pj_path = path+"\\"+pj
    #     dict1 = extractLineASM(pj_path)
    #     mappingFile(pj_path,dict1)
    # extractLineASM("D:\\Master_Project\\SLICE_origin\\SARD_SLICE\\0\\000000014")

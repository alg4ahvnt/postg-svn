# 开发时间 2023/9/7 21:31
import os

import torch
from torch import nn
import torch.nn.functional as F
from tqdm import tqdm


class BiLSTM(nn.Module):
    def __init__(self,embedding_dim,hidden_dim,num_layers):
        super(BiLSTM, self).__init__()
        self.embedding_dim = embedding_dim
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers

        self.rnn1 = nn.LSTM(embedding_dim,hidden_dim1,..)

        #聚合:求每个句子平均

        self.rnn = nn.LSTM(embedding_dim, hidden_dim, num_layers=num_layers,
                           bidirectional=True, dropout=0.5)
        #聚合：求每个函数平均


        self.fc = nn.Linear(hidden_dim * 2 , 2)

    def forward(self,x):
        # x (batch_size,seq_len,embedding)
        x = x.permute(1,0,2)
        # x (seq_len,batch_size,embedding)
        output,(final_hidden_state,final_cell_state) = self.rnn(x)
        output = output.permute(1,0,2)
        logit = self.fc(output)
        result = logit
        return result
class BiGRU(nn.Module):
    def __init__(self,embedding_dim,hidden_dim,num_layers):
        super(BiGRU,self).__init__()
        self.embedding_dim = embedding_dim
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        self.rnn = nn.GRU(embedding_dim, hidden_dim, num_layers=num_layers,
                           bidirectional=True, dropout=0.5)
        self.fc = nn.Linear(hidden_dim * 2, 2)
    def forward(self,x):
        # x (batch_size,seq_len,embedding)
        x = x.permute(1,0,2)
        # x (seq_len,batch_size,embedding)
        output,_ = self.rnn(x)
        output = output.permute(1,0,2)
        logit = self.fc(output)
        result = logit
        return result
class BiLSTM_Attention(nn.Module):
    def __init__(self,embedding_dim,hidden_dim,num_layers):
        super(BiLSTM_Attention,self).__init__()
        self.embedding_dim = embedding_dim
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        self.rnn = nn.LSTM(embedding_dim,hidden_dim,num_layers = num_layers,
                           bidirectional=True,dropout=0.5)
        self.fc = nn.Linear(hidden_dim * 2 , 2)
        self.dropout = nn.Dropout(0.5)
        self.w_omega = nn.Parameter(torch.Tensor(hidden_dim * 2, hidden_dim * 2))
        self.u_omega = nn.Parameter(torch.Tensor(hidden_dim * 2, 1))
        nn.init.uniform_(self.w_omega, -0.1, 0.1)
        nn.init.uniform_(self.u_omega, -0.1, 0.1)
    def attention_net(self,x): # x:(batch_size,seq_len,hidden_dim * 2)
        u = torch.tanh(torch.matmul(x,self.w_omega)) # u:(batch_size,seq_len,hidden_dim * 2)
        att = torch.torch.matmul(u,self.u_omega) # att:(batch_size,seq_len,1)
        att_score = F.softmax(att,dim = 1) #获得每一个句子的注意力分数
        scored_x = x * att_score # scored_x:(batch_size,seq_len,hidden_dim * 2)
        # context = torch.sum(scored_x,dim = 1) #对所有句子求和 获得段落上下文 细粒度不需要
        return scored_x
    def forward(self,x):
        # x (batch_size,seq_len,embedding)
        x = x.permute(1, 0, 2)
        # x (seq_len,batch_size,embedding)
        output, (final_hidden_state, final_cell_state) = self.rnn(x)
        output = output.permute(1, 0, 2)
        attn_output = self.attention_net(output)
        logit = self.fc(attn_output) # (batch_size,seq_len,2)
        return logit
class Code_NN(nn.Module):
    def __init__(self):
        super(Code_NN,self).__init__()
        self.FC1 = nn.Sequential(
            nn.Linear(768,128),
            nn.ReLU(),
        )
        self.FC2 = nn.Sequential(
            nn.Linear(128,2),
            nn.ReLU(),
        )
        # self.FC3 = nn.Sequential(
        #     nn.Linear(30,2),
        #     nn.ReLU(),
        # )
    def forward(self,x):
        #print(x.shape)
        x = self.FC1(x)
        #print(x.shape)
        x = self.FC2(x)
        #print(x.shape)
        #print(x.shape)
        return x
class TModel(nn.Module):
    def __init__(self,dim = 768):
        super(TModel,self).__init__()

        self.Query_matrix = nn.Linear(dim,dim,bias = False)
        self.Key_matrix = nn.Linear(dim,dim,bias = False)
        self.Value_matrix = nn.Linear(dim,dim,bias = False)

        #Dropout层
        self.dropout = nn.Dropout(0.5)
        self.scale = torch.sqrt(torch.FloatTensor([dim]))
        self.relu = nn.ReLU()
        #双向LSTM层
        self.biLSTM = nn.LSTM(768, 256, num_layers=2, batch_first=True,bidirectional=True)
        self.fc = nn.Linear(512,2)
        self.softmax = nn.Softmax(dim = 2)
    def forward(self,x,device):
        '''
        :param x: 特征矩阵 维度（batch-size,15,768）
        '''
        Q = self.Query_matrix(x).to(device)
        K = self.Key_matrix(x).to(device)
        V = self.Value_matrix(x).to(device)
        scaled_scores = torch.matmul(Q,K.transpose(1,2))/self.scale.to(device)
        #注意力权重
        attn_weights = self.dropout(torch.softmax(scaled_scores,dim=-1))
        #得到self-attention后的表示
        attn_output = torch.matmul(attn_weights,V)
        attn_output = self.relu(attn_output)
        out,_ = self.biLSTM(attn_output)
        out = self.fc(out)

        return out
if __name__ == "__main__":
    path = "D:\\Master_Project\\0217\\Torch"
    for file in tqdm(os.listdir(path)):
        a = torch.load(path+"\\"+file).size()
        if a != torch.Size([20,768]):
            print(file)
            print(a)
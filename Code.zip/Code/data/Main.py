# 开发时间 2023/10/21 14:27
import os

import torch
from torch import nn
from tqdm import tqdm

if __name__ == "__main__":
    #print(torch.cuda.is_available())
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    # path = "D:\\kyk\\Experiment\\OPENSSL Result\\OPENSSL_Renamed"
    # for file in tqdm(os.listdir(path)):
    #     with open(path+'\\'+file,'r') as f1:
    #         lines = f1.readlines()
    #         flag = False
    #         line_Num = 0
    #         for line in lines:
    #             if line == lines[0]:
    #                 continue
    #             if "--------------------------" in line:
    #                 break
    #             line_Num+=1
    #             if '''strlen ( stonesoup_data . buff_pointer );''' in line:
    #                 if line.split(" ")[-1].rstrip() == "N":
    #                     print(file)
    #
    #
    #     f1.close()
    model = torch.load("D:\\kyk\\Experiment\\OPENSSL Result\\1612.pt")
    tensor1 = torch.load("C:\\Users\\柯晔坤\\Desktop\\0000\\153543_21#0.pt").to(device)
    tensor2 = torch.load("C:\\Users\\柯晔坤\\Desktop\\0000\\153543_21#1.pt").to(device)
    tensor3 = torch.load("C:\\Users\\柯晔坤\\Desktop\\0000\\153543_21#2.pt").to(device)
    tensor4 = torch.load("C:\\Users\\柯晔坤\\Desktop\\0000\\153543_21#3.pt").to(device)
    softmax = nn.Softmax(dim = 0)
    result1 = model(tensor1.unsqueeze(dim = 0))

    result2 = model(tensor2.unsqueeze(dim=0))
    result3 = model(tensor3.unsqueeze(dim=0))
    result4 = model(tensor4.unsqueeze(dim=0))
    for i in range(20):
        if torch.equal(tensor1[i],torch.zeros([768]).to(device))==False:
            print(softmax(result1[0][i]))
    for i in range(20):
        if torch.equal(tensor2[i], torch.zeros([768]).to(device))==False:
            print(softmax(result2[0][i]))

    for i in range(20):
        if torch.equal(tensor3[i], torch.zeros([768]).to(device))==False:
            print(softmax(result3[0][i]))
    for i in range(20):
        if torch.equal(tensor4[i], torch.zeros([768]).to(device))==False:
            print(softmax(result4[0][i]))





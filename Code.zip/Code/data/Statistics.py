# 开发时间 2023/10/19 17:47
import os
import random
import shutil
import time
from hashlib import md5

import torch
from torch import nn
from tqdm import tqdm
from transformers import AutoModel, AutoTokenizer

from data.CodeBert_process import slice_process, code_to_tensor, deleteNumAndTag, deleteACUselessInfo
from data.MappingSToA import extractLineASM
from data.Re_Duplicate import judge_P_or_N





def tokenizerLimited():
    print('loading model...')
    tokenizer = AutoTokenizer.from_pretrained("C:\\Users\\柯晔坤\\codebert-base")
    added_token = ["rax", "mov", "push", "pop", "xchg", "cmp", "call", "lea", "movsx", "add", "adc", "sub", "sbb",
                   "cdqe", "sal", "test", "nop", "jmp", "pushf", "popf", "pusha", "popa", "lds", "les", "inc", "dec", "mul", "imul", "neg", "div",
                   "idiv", "cbw", "cwd", "and", "or", "xor", "not", "shr", "shl", "sar", "sal", "ror", "rol", "rcr", "rcl",
                   "clc", "stc", "cmc",  "cld", "std", "jle", "jbe", "je", "movw", "js", "ja", "jg", "jne", 'jnb', "iret", "jz", "al", "eax",
                   "edx", "edi", "esi",  "rsi", "rbp", "rsp", "rcx", "rdx", "DWORD", "QWORD", "PTR", "BYTE", "OFFSET", "FLAT", "XMMWORD",
                   "movabs", "DWORD", "ret", "jns", "movzx", "PTR", "sete"]
    tokenizer.add_tokens(added_token)
    model = AutoModel.from_pretrained("C:\\Users\\柯晔坤\\codebert-base", added_token)
    # 添加词汇后重现变化大小
    model.resize_token_embeddings(len(tokenizer))
    print('processing...')
    # 待处理路径
    path = "D:\\kyk\\Experiment\\SVN Result\\SVN_Processed"

    for file in tqdm(os.listdir(path)):
        print("Processing: "+file)
        file_path = path + "\\" + file
        SC, AC, S = slice_process(file_path)
        SC_tokens = tokenizer.tokenize(SC)
        AC_tokens = tokenizer.tokenize(AC)
        if (len(SC_tokens) + len(AC_tokens) >= 507):
            crop(file_path,tokenizer)
        else:
            shutil.copy(file_path,"D:\\kyk\\Experiment\\SVN Result\\SVN_Cropped\\"+file.split(".")[0]+"#0.txt")
def judgeNum(file_name):
    path = "D:\\kyk\\Experiment\\SVN Result\\SVN_Cropped"
    files = os.listdir(path)
    len = 0
    for file in files:
        if file_name.split(".")[0] == file.split("#")[0]:
            len+=1
    return len

def deletePouseLongFile():
    print('loading model...')
    tokenizer = AutoTokenizer.from_pretrained("C:\\Users\\柯晔坤\\codebert-base")
    added_token = ["rax", "mov", "push", "pop", "xchg", "cmp", "call", "lea", "movsx", "add", "adc", "sub", "sbb",
                   "cdqe", "sal", "test", "nop", "jmp", "pushf", "popf", "pusha", "popa", "lds", "les", "inc", "dec",
                   "mul", "imul", "neg", "div",
                   "idiv", "cbw", "cwd", "and", "or", "xor", "not", "shr", "shl", "sar", "sal", "ror", "rol", "rcr",
                   "rcl",
                   "clc", "stc", "cmc", "cld", "std", "jle", "jbe", "je", "movw", "js", "ja", "jg", "jne", 'jnb',
                   "iret", "jz", "al", "eax",
                   "edx", "edi", "esi", "rsi", "rbp", "rsp", "rcx", "rdx", "DWORD", "QWORD", "PTR", "BYTE", "OFFSET",
                   "FLAT", "XMMWORD",
                   "movabs", "DWORD", "ret", "jns", "movzx", "PTR", "sete"]
    tokenizer.add_tokens(added_token)
    model = AutoModel.from_pretrained("C:\\Users\\柯晔坤\\codebert-base", added_token)
    # 添加词汇后重现变化大小
    model.resize_token_embeddings(len(tokenizer))
    print('processing...')
    path = "D:\\kyk\\Experiment\\POUSE Result\\POUSE_Processed"
    for file in tqdm(os.listdir(path)):
        file_path = path + "\\" + file
        SC, AC, S = slice_process(file_path)
        list = SC.split("\n")
        for item in list:
            SC_tokens = tokenizer.tokenize(item)
            if len(SC_tokens)>507:
                print(file)
                shutil.move(path+'\\'+file,"D:\\kyk\\Experiment\\POUSE Result\\Remove\\"+file)
                break



def crop(file_path,tokenizer):
    file_name = file_path.split("\\")[-1]
    project_name = file_name.split('_')[0]
    project_path = "D:\\kyk\\Experiment\\SVN Result\\SVN_Origin\\"+project_name
    newCroppedFileSC = []
    newCroppedFileAC = []
    dict = extractLineASM(project_path)
    with open(file_path,'r') as f1:
        lines = f1.readlines()
        newCroppedFileSC.append(lines[0])
        newCroppedFileAC.append(lines[0])
        for index in range(len(lines)):
            if index == 0:
                continue
            if "---------------------" not in lines[index]:
                tmpSC = newCroppedFileSC.copy()
                tmpAC = newCroppedFileAC.copy()
                before_num = calculate_all_tokens_num(tmpSC, tmpAC, tokenizer)
                i = 0
                if(before_num>507):
                    while before_num>507:
                        i += 1
                        before_num = calculate_all_tokens_num(tmpSC,tmpAC[0:len(tmpAC)-i],tokenizer)
                    write_cropping_file(file_name,tmpSC,tmpAC[0:len(tmpAC)-i])
                    new_SC = []
                    new_SC.append(newCroppedFileSC[0])
                    newCroppedFileSC = new_SC.copy()
                    new_AC = []
                    new_AC.append(newCroppedFileAC[0])
                    newCroppedFileAC = new_AC.copy()

                    newCroppedFileSC.append(lines[index])
                    lineNum = int(lines[index].split(" ")[-2])
                    if lineNum in dict.keys():
                        newCroppedFileAC.extend(dict.get(lineNum))
                    continue
                newCroppedFileSC.append(lines[index])
                lineNum = 10000
                if lines[index].split(" ")[-2].isdigit():
                    lineNum = int(lines[index].split(" ")[-2])
                if lineNum in dict.keys():
                    newCroppedFileAC.extend(dict.get(lineNum))
                after_num = calculate_all_tokens_num(newCroppedFileSC,newCroppedFileAC,tokenizer)
                if (before_num<=507) & (after_num>507):
                    new_SC = []
                    new_SC.append(newCroppedFileSC[0])
                    new_SC.append(newCroppedFileSC[-1])
                    newCroppedFileSC = new_SC.copy()
                    new_AC = []
                    new_AC.append(newCroppedFileAC[0])
                    if lineNum in dict.keys():
                        new_AC.extend(dict.get(lineNum))
                    newCroppedFileAC = new_AC.copy()
                    if(before_num!=0):
                        write_cropping_file(file_name,tmpSC,tmpAC)

            else:
                if(len(newCroppedFileSC)!=1):
                    tmpSC = newCroppedFileSC.copy()
                    tmpAC = newCroppedFileAC.copy()
                    before_num = calculate_all_tokens_num(tmpSC, tmpAC, tokenizer)
                    i = 0
                    if before_num > 507:
                        while before_num>507:
                            i += 1
                            before_num = calculate_all_tokens_num(tmpSC,tmpAC[0:len(tmpAC)-i],tokenizer)
                        write_cropping_file(file_name,tmpSC,tmpAC[0:len(tmpAC)-i])
                    else:
                        write_cropping_file(file_name,tmpSC,tmpAC)
                break
    f1.close()
def calculate_all_tokens_num(SC,AC,tokenizer):
    num = 0
    for sc_code in SC:
        if(sc_code == SC[0]):
            continue
        sc_code = deleteNumAndTag(sc_code)
        sc_tokens = tokenizer.tokenize(sc_code[0])
        num = num+len(sc_tokens)
    for ac_code in AC:
        if(ac_code == AC[0]):
            continue
        ac_code = deleteACUselessInfo(ac_code)
        ac_tokens = tokenizer.tokenize(ac_code)
        num = num+len(ac_tokens)
    return num
def write_cropping_file(file_name,SC,AC):
    file_num = judgeNum(file_name)
    with open("D:\\kyk\\Experiment\\SVN Result\\SVN_Cropped\\" +file_name.split(".")[0]+"#"+ str(file_num) + ".txt", 'w') as f2:
        f2.writelines(SC)
        f2.writelines("---------------------------------------------------------------------\n")
        for index in range(len(AC)):
             if index == 0:
                 f2.writelines(AC[index])
             else:
                 f2.writelines(AC[index] + "\n")

    f2.close()
# 删除真实项目中没有AC的SC代码
def delete_SC_with_no_AC():
    path = "D:\\kyk\\Experiment\\POUSE Result\\POUSE_Processed"
    files = os.listdir(path)
    list = []
    for file in tqdm(files):
        file_path = path + "\\" + file
        with open(file_path,'r') as f1:
            lines = f1.readlines()
            if('----------------------' in lines[-2]):
                list.append(file)
        f1.close()

    for item in list:
        shutil.move(path+"\\"+item,"D:\\kyk\\Experiment\\POUSE Result\\Remove\\"+item)
    print("删除完成!")
# 将真实项目中-v1.0.0字符串删除 便于后续操作
def real_rename():
    path = "D:\\kyk\\Experiment\\OPENSSL Result\\OPENSSL_Processed"
    files = os.listdir(path)
    for file in tqdm(files):
        list = file.split("-v1.0.0")
        file1 = list[0]+list[1]
        print(file1)
        shutil.move(path+"\\"+file,"D:\\kyk\\Experiment\\OPENSSL Result\\OPENSSL_Renamed\\"+file1)
# 统一Torch大小
def deleteUniqueLongTensor():
    path = "D:\\kyk\\Experiment\\POUSE Result\\POUSE\\Torch"
    for file in tqdm(os.listdir(path)):
        torch1 = torch.load(path+"\\"+file)
        if torch1.size() != torch.Size([20,768]):
            os.remove(path+"\\"+file)
            os.remove("D:\\kyk\\Experiment\\POUSE Result\\POUSE\\Label\\"+file)


if __name__ == "__main__":
    tokenizerLimited()

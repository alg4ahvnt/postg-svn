# 开发时间 2023/8/30 12:38
import os
import random
import shutil

import torch
import torch.utils.data as Data
from torch import nn
from torch.utils.data import DataLoader
from tqdm import tqdm

from data.Encoder import BiLSTM, BiLSTM_Attention, BiGRU, Code_NN, TModel
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")







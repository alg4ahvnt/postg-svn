# 开发时间 2023/9/2 13:22
import os
from math import sqrt
import torch
import torch.nn as nn
from torch import device, optim
import dill
from torch.utils.data import DataLoader
from tqdm import tqdm
from transformers import AutoTokenizer, AutoModel

from data.CodeBert_process import slice_process, code_to_tensor
from data.DataSet import SADataSet
from data.Encoder import BiGRU, Code_NN


def train(EPOCH,train_loader):
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    print(device)
    net = TModel().to(device)
    optimizer = optim.Adam(net.parameters(),lr = 1e-3)
    for epoch in tqdm(range(EPOCH)):
        train_loss = 0.0
        for i , (tensors , labels) in enumerate(train_loader):
            tensors = tensors.to(device)
            labels = labels.to(device)
            #optimizer.zero_grad()
            predictions = net(tensors,device)  #(16,23,2)
            #每一个batch 平均loss计算
            predictions_reshape = predictions.view(-1,2)  #(16*23,2)
            labels_reshape = labels.view(-1) #(16*23)
            loss_fn = nn.CrossEntropyLoss(reduction="none")

            #predictions_reshape = torch.tensor(predictions_reshape,dtype = torch.long)
            #labels_reshape = torch.tensor(labels_reshape,dtype = torch.long)

            losses = loss_fn(predictions_reshape,labels_reshape)
            if(losses.size(0) == 368):
                losses = losses.view(16, 23)
            else:
                losses = losses.view(int(losses.size()[0]/23),23)

            avg_losses = losses.mean(dim = 1)
            #反向传播过程
            optimizer.zero_grad()
            avg_losses.backward(torch.ones_like(avg_losses))
            optimizer.step()
            train_loss += avg_losses.sum()
        print("Epoch:   %3d,   Loss:    %.7f"%(epoch+1,train_loss/(len(train_loader))))
        torch.save(net, 'D:\\Tao_Seq2Seq.pt')
def test1(net):
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    # path = "D:\\Master_Project\\1024(OpenSSL)\\Five\\Split0\\Test\\Encode"
    # label_path = "D:\\Master_Project\\1024(OpenSSL)\\Five\\Split0\\Test\\Label"
    path = "D:\\kyk\\torch\\Test\\Encode"
    label_path = "D:\\kyk\\torch\\Test\\Label"
    files = os.listdir(path)
    sm = nn.Softmax(dim = 2)
    True_Positive = 0
    False_Positive = 0
    True_Negative = 0
    False_Negative = 0
    str1 = ""
    for file in tqdm(files):
        tensor = torch.load(path+"\\"+file).unsqueeze(0).to(device) #(1,15,768)
        label = torch.load(label_path+"\\"+file)#(15)
        predicts = sm(net(tensor)) #(1,15,2)
        count = 0
        for i in range(12):
            if (not torch.equal(tensor[0][i], torch.zeros((768)).to(device))):
                count += 1
        for i in range(count):
            if(torch.equal(torch.argmax(predicts[0][i]),torch.tensor(1).to(device))):
                if(torch.equal(label[i],torch.tensor(1))):
                    True_Positive += 1
                    str1 = str1+project_CWE(file.split("_")[0])+" TP\n"
                elif(torch.equal(label[i],torch.tensor(0))):
                    False_Positive += 1
            elif(torch.equal(torch.argmax(predicts[0][i]),torch.tensor(0).to(device))):
                if (torch.equal(label[i],torch.tensor(1))):
                    False_Negative += 1
                    str1 = str1 + project_CWE(file.split("_")[0]) + " FN\n"
                elif(torch.equal(label[i],torch.tensor(0))):
                    True_Negative += 1
    print("TP:")
    print(True_Positive)
    print("FP:")
    print(False_Positive)
    print("TN:")
    print(True_Negative)
    print("FN:")
    print(False_Negative)
    print("precision:")
    pre = precision(True_Positive,False_Positive,True_Negative,False_Negative)
    print(pre)
    print("recall:")
    rec = recall(True_Positive,False_Positive,True_Negative,False_Negative)
    print(rec)
    f1 = 2*pre*rec/(pre+rec)
    print("F1:")
    print(f1)
    print("accuracy:")
    print(accuracy(True_Positive,False_Positive,True_Negative,False_Negative))
    print("FPR:")
    print(FPR(True_Positive,False_Positive,True_Negative,False_Negative))
    print("IOU:")
    print(IOU(True_Positive, False_Positive, True_Negative, False_Negative))
    with open("D:\\kyk\\SVN_CWE_BiGRU.txt",'w') as f2:
        f2.writelines(str1)
    f2.close()
def project_CWE(file_path):
    path = "D:\\kyk\\SVN\\"+file_path+"-v1.0.0"
    info = path+"\\"+"manifest.sarif"
    with open(info,'r') as f1:
        lines = f1.readlines()
        for index in range(len(lines)):
            if "taxa" in lines[index]:
                if "id" in lines[index+2]:
                    str  = (lines[index+2].rstrip().split("\"")[-2])
    f1.close()
    return "CWE-"+str
def recall(TP,FP,TN,FN):
    return round(TP/(TP+FN),7)
def precision(TP,FP,TN,FN):
    return round(TP/(TP+FP),7)
def accuracy(TP,FP,TN,FN):
    return round((TP+TN)/(TP+FP+TN+FN),7)
def FPR(TP,FP,TN,FN):
    return round(FP/(FP+TN),7)
def IOU(TP,FP,TN,FN):
    return round(TP/(TP+FN+FP),7)



def CWE_gather(file_path):
    all_cwe = {}
    list_cwe = []
    right = []
    wrong = []
    with open(file_path,'r') as f1:
        lines = f1.readlines()
        for line in lines:
            line = line.rstrip()
            list = line.split(" ")
            cwe = list[0]
            res = list[1]
            if cwe not in list_cwe:
                list_cwe.append(cwe)
                if res == 'TP':
                    right.append(1)
                    wrong.append(0)
                else:
                    wrong.append(1)
                    right.append(0)
            elif cwe in list:
                index = list_cwe.index(cwe)
                if res == 'TP':
                    a = right[index]+1
                    right[index] = a
                else:
                    a = wrong[index]+1
                    wrong[index] = a
    print(list_cwe)
    print(right)
    print(wrong)
    with open("D:\\Master_Project\\statitics.txt",'w') as f2:
        f2.writelines("CWE_name    TP    FN    Correct_rate\n")
        for index in range(len(list_cwe)):
            correct_rate = (right[index])/(right[index]+wrong[index])
            f2.writelines(list_cwe[index]+"     "+str(right[index])+"     "+str(wrong[index])+"     "+str(round(correct_rate,4))+"\n")
    f2.close()
    f1.close()
if __name__ == '__main__':

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

    net = torch.load("D:\\kyk\\SVN_LimitedP_BiGRU.pt").to(device)
    test1(net)




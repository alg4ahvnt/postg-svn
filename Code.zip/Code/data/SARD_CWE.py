# 开发时间 2023/11/5 19:46
import os
import re
import time

import torch
from torch import nn
from tqdm import tqdm


def extract_pj_cwe_info():
    path = "D:\\Master_Project\\SLICE\\SARD_testcaseinfo.xml"
    with open(path,'r') as f1:
        lines = f1.readlines()
        number_tag = False
        cwe_tag = False
        with open("D:\\kyk\\CWE_sard.txt",'w') as f2:
            for index in range(len(lines)):
                if ("<testcase" in lines[index]) & ("/testcase" not in lines[index] ) & ("association" not in lines[index]):
                    f2.writelines(lines[index])
                if ("CWE" in lines[index]) & ("description" not in lines[index]) & ("<file path" not in lines[index]):
                    f2.writelines(lines[index])
        f2.close()
    f1.close()
def get_CWE(id_number):
    with open("D:\\kyk\\CWE_sard.txt",'r') as f1:
        lines = f1.readlines()
        index = -1
        for i in range(len(lines)):
            if "id=\""+str(id_number)+"\"" in lines[i]:
                index = i+1
                break
        match_obj = None
        if("<testcase" not in lines[index]):
            pattern = r'\d+'
            match_obj = re.findall(pattern, lines[index].lstrip().split(" ")[2])
    f1.close()
    if match_obj == None:
        print(id_number)
        time.sleep(20)
        return "CWE-None"
    return "CWE-"+str(match_obj[0])
def SARD_test(net):
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    # path = "D:\\Master_Project\\1024(OpenSSL)\\Five\\Split0\\Test\\Encode"
    # label_path = "D:\\Master_Project\\1024(OpenSSL)\\Five\\Split0\\Test\\Label"
    path = "D:\\Master_Project\\SARD_Test\\encode"
    label_path = "D:\\Master_Project\\SARD_Test\\label"
    files = os.listdir(path)
    sm = nn.Softmax(dim=2)
    True_Positive = 0
    False_Positive = 0
    True_Negative = 0
    False_Negative = 0
    str1 = ""
    for file in tqdm(files):
        print("-------------------------------------------------------------")
        print(file)
        tensor = torch.load(path + "\\" + file).unsqueeze(0).to(device)  # (1,15,768)
        label = torch.load(label_path + "\\" + file)  # (15)
        predicts = sm(net(tensor))  # (1,15,2)
        count = 0
        for i in range(20):
            if (not torch.equal(tensor[0][i], torch.zeros((768)).to(device))):
                count += 1
        for i in range(count):
            if (torch.equal(torch.argmax(predicts[0][i]), torch.tensor(1).to(device))):
                if (torch.equal(label[i], torch.tensor(1))):
                    True_Positive += 1
                    file_id = getID(file)
                    CWE = get_CWE(file_id)
                    str1 = str1 + CWE + " TP\n"
                elif (torch.equal(label[i], torch.tensor(0))):
                    False_Positive += 1
            elif (torch.equal(torch.argmax(predicts[0][i]), torch.tensor(0).to(device))):
                if (torch.equal(label[i], torch.tensor(1))):
                    False_Negative += 1
                    file_id = getID(file)
                    CWE = get_CWE(file_id)
                    str1 = str1 + CWE + " FN\n"
                elif (torch.equal(label[i], torch.tensor(0))):
                    True_Negative += 1
    print("TP:")
    print(True_Positive)
    print("FP:")
    print(False_Positive)
    print("TN:")
    print(True_Negative)
    print("FN:")
    print(False_Negative)
    print("precision:")
    pre = precision(True_Positive, False_Positive, True_Negative, False_Negative)
    print(pre)
    print("recall:")
    rec = recall(True_Positive, False_Positive, True_Negative, False_Negative)
    print(rec)
    f1 = 2 * pre * rec / (pre + rec)
    print("F1:")
    print(f1)
    print("accuracy:")
    print(accuracy(True_Positive, False_Positive, True_Negative, False_Negative))
    print("FPR:")
    print(FPR(True_Positive, False_Positive, True_Negative, False_Negative))
    print("IOU:")
    print(IOU(True_Positive, False_Positive, True_Negative, False_Negative))
    with open("D:\\Master_Project\\SARD_CWE_BiGRU.txt", 'w') as f2:
        f2.writelines(str1)
    f2.close()
def recall(TP,FP,TN,FN):
    return round(TP/(TP+FN),7)
def precision(TP,FP,TN,FN):
    return round(TP/(TP+FP),7)
def accuracy(TP,FP,TN,FN):
    return round((TP+TN)/(TP+FP+TN+FN),7)
def FPR(TP,FP,TN,FN):
    return round(FP/(FP+TN),7)
def IOU(TP,FP,TN,FN):
    return round(TP/(TP+FN+FP),7)
def getID(file_name):
    str_list = [char for char in file_name.split("_")[0]]
    id = ""
    for i in range(len(str_list)):
        if i == 0:
            continue
        if str_list[i] == '0':
            continue
        id = id + str_list[i]
    return id
if __name__ == "__main__":
    net = torch.load("D:\\Master_Project\\Sard_BiGRU.pt")
    SARD_test(net)
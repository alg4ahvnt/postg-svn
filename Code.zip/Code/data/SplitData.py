# 开发时间 2023/8/28 21:54
# 将每一个slice的SC和AC放入一个单独的文件 并按7:3划分训练集和数据集
import os
import random
from tqdm import tqdm,trange

def judgeNum(pjName,path):
    files = os.listdir(path)
    count = 0
    for file in files:
        if(file.split('_')[0] == pjName):
            count+=1
    return count

def txt_process(pjName,SPath,APath):
    SList = []
    AList = []
    with open(SPath,'r') as f1:
        lines = f1.readlines()
        sliceList = []
        for line in lines:
            if ('-------' not in line):
                sliceList.append(line)
            else:
                SList.append(sliceList)
                sliceList = []
    f1.close()
    with open(APath,'r') as f2:
        lines = f2.readlines()
        sliceList =[]
        for line in lines:
            if('-------' not in line):
                sliceList.append(line)
            else:
                AList.append(sliceList)
                sliceList=[]
    f2.close()
    if(len(SList) != len(AList)):
        print("Something Wrong!!!!!!!!!!!")
        exit(1)
    for i in range(len(SList)):
        path = "D:\\Master_Project\\Sard_All_Function"
        num = judgeNum(pjName,path)
        with open(path+'\\'+pjName+"_"+str(num)+'.txt','w') as f1:
            list = SList[i]
            for line in list:
                f1.writelines(line)
            f1.writelines('---------------------------------------------------------------------------------\n')
            list = AList[i]
            for line in list:
                f1.writelines(line)
        f1.close()
def partition_data():
    path = "D:\\Master_Project\\SLICE_origin\\SARD_SLICE\\"
    i = 0
    for i in tqdm(range(25)):
        root_path = path+"\\"+str(i)+"\\"
        projects = os.listdir(root_path)
        for project in tqdm(projects):
            #print("processing：   "+project)
            project_root = root_path+project
            pj_files = os.listdir(project_root)
            for pj_file in pj_files:
                if (str(pj_file).endswith('_tagFlaw.txt')):
                    new_str = str(pj_file.replace('_tagFlaw.txt', '.txt.asm'))
                    SPath = project_root  + "\\" + str(pj_file)
                    APath = project_root  + "\\" + new_str
                    txt_process(project,SPath, APath)
                else:
                    continue


def real_compare_num(pj_path):
    print("Processing:   "+pj_path)
    files = os.listdir(pj_path)
    S_Num = 0
    A_Num = 0
    for file in files:
        tmp_S_Num = 0
        tmp_A_Num = 0
        if(str(file).endswith('_tagFlaw.txt')):
            new_str = str(file.replace('_tagFlaw.txt', '.txt.asm'))
            SPath = pj_path + "\\" + str(file)
            APath = pj_path + "\\" + new_str
            with open(SPath, 'r') as f1:
                lines = f1.readlines()
                for line in lines:
                    if '-------'  in line:
                        S_Num+=1
                        tmp_S_Num+=1
            f1.close()
            with open(APath,'r') as f2:
                lines = f2.readlines()
                for line in lines:
                    if '-------' in line:
                        A_Num+=1
                        tmp_A_Num+=1
            f2.close()
            if(tmp_S_Num!=tmp_A_Num):
                exit(2)
    print("S_Num:"+str(S_Num))
    print("A_Num:"+str(A_Num))

if __name__ == '__main__':
    partition_data()



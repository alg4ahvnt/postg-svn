# 开发时间 2023/10/23 14:20
import hashlib
import os
import shutil
import time
from hashlib import md5
import random
import difflib
from tqdm import tqdm


def Re_Duplicate():
    path = "D:\\kyk\\Method_Crop"
    set1 = set([])
    to_remove = []
    for file in tqdm(os.listdir(path)):
        with open(path+"\\"+file,'r') as f1:
            lines = f1.readlines()
            str = ""
            for index in range(len(lines)):
                if index == 0:
                    continue
                if "----------" in lines[index]:
                    break
                else:
                    list = lines[index].rstrip().split(" ")
                    list.pop()
                    list.pop()
                    for item in list:
                        str = str+item+" "
            obj = hashlib.md5()
            obj.update(str.encode('utf-8'))
            value = obj.hexdigest()
            if value in set1:
                to_remove.append(file)
            else:
                set1.update({value})
        f1.close()
    print(len(set1))
    for file in to_remove:
        if(judge_P_or_N(path+"\\"+file) == True):
            shutil.move("D:\\kyk\\Method_Crop\\"+file,"D:\\kyk\\Delete\\"+file)
        else:
            shutil.move("D:\\kyk\\Method_Crop\\"+file,"D:\\kyk\\Delete\\"+file)
def judge_P_or_N(file_path):
    with open(file_path,'r') as f1:
        lines = f1.readlines()
        for index in range(len(lines)):
            if index == 0:
                continue
            if "------------" in lines[index]:
                break
            else:
                if(lines[index].rstrip().split(" ")[-1]=="P"):
                    return True
        return False

def limitedPositive():
    path="D:\\kyk\\POUSE_Processed"
    dict1 = {}
    for file in os.listdir(path):
        if judge_P_or_N(path+"\\"+file):
            print("------------------------------------")
            print(file)
            pj_name = file.split("_")[0]
            if pj_name not in dict1.keys():
                dict1.update({pj_name:1})
            else:
                num = dict1.get(pj_name)
                if num == 3:
                    if random.random()>0.2:
                        print("moving to DeletePositive...")
                        shutil.move(path+"\\"+file,"D:\\kyk\\Delete\\"+file)
                else:
                    num += 1
                    dict1.update({pj_name:num})




if __name__ == "__main__":
    Re_Duplicate()
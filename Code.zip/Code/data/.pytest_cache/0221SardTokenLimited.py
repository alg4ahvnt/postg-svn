# 开发时间 2024/2/21 15:48
import os
import shutil

from tqdm import tqdm
from transformers import AutoTokenizer, AutoModel

from data.CodeBert_process import slice_process
from data.Statistics import calculate_all_tokens_num, write_cropping_file


def SardTokenLimited():
    print('loading model...')
    tokenizer = AutoTokenizer.from_pretrained("C:\\Users\\柯晔坤\\codebert-base")
    added_token = ["rax", "mov", "push", "pop", "xchg", "cmp", "call", "lea", "movsx", "add", "adc", "sub", "sbb",
                   "cdqe", "sal", "test", "nop", "jmp", "pushf", "popf", "pusha", "popa", "lds", "les", "inc", "dec",
                   "mul", "imul", "neg", "div", "idiv", "cbw", "cwd", "and", "or", "xor", "not", "shr", "shl", "sar", "sal", "ror", "rol", "rcr",
                   "rcl","clc", "stc", "cmc", "cld", "std", "jle", "jbe", "je", "movw", "js", "ja", "jg", "jne", 'jnb',
                   "iret", "jz", "al", "eax","edx", "edi", "esi", "rsi", "rbp", "rsp", "rcx", "rdx", "DWORD", "QWORD", "PTR", "BYTE", "OFFSET",
                   "FLAT", "XMMWORD","movabs", "DWORD", "ret", "jns", "movzx", "PTR", "sete"]
    tokenizer.add_tokens(added_token)
    model = AutoModel.from_pretrained("C:\\Users\\柯晔坤\\codebert-base", added_token)
    # 添加词汇后重现变化大小
    model.resize_token_embeddings(len(tokenizer))
    print('processing...')

    path = "D:\\Master_Project\\Sard_All_Function"
    for file in tqdm(os.listdir(path)):
        print("Processing: " + file)
        file_path = path + "\\" + file
        SC, AC, S = slice_process(file_path)
        SC_tokens = tokenizer.tokenize(SC)
        AC_tokens = tokenizer.tokenize(AC)
        if (len(SC_tokens) + len(AC_tokens) >= 511):
            crop(file_path,tokenizer)
        else:
            shutil.copy(path+"\\"+file,"D:\\Master_Project\\Sard_Croped_Function\\"+file.split(".")[0]+"_0.txt")
        #print(len(SC_tokens) + len(AC_tokens))
def crop(file_path,tokenizer):
    file_name = file_path.split("\\")[-1]
    newCroppedFileSC = []
    newCroppedFileAC = []
    with open(file_path,'r') as f1:
        lines = f1.readlines()
        newCroppedFileSC.append(lines[0])
        for index2 in range(len(lines)):
            if "-----------" in lines[index2]:
                newCroppedFileAC.append(lines[index2+1])
        for index in range(len(lines)):
            if index == 0:
                continue
            if "---------------------" not in lines[index]:
                tmpSC = newCroppedFileSC.copy()
                tmpAC = newCroppedFileAC.copy()
                before_num = calculate_all_tokens_num(tmpSC, tmpAC, tokenizer)
                i = 0
                if (before_num > 508):
                    while before_num>508:
                        i += 1
                        before_num = calculate_all_tokens_num(tmpSC,tmpAC[0:len(tmpAC)-i],tokenizer)
                    write_cropping_file(file_name,tmpSC,tmpAC[0:len(tmpAC)-i])
                    new_SC = []
                    new_SC.append(newCroppedFileSC[0])
                    newCroppedFileSC = new_SC.copy()
                    new_AC = []
                    new_AC.append(newCroppedFileAC[0])
                    newCroppedFileAC = new_AC.copy()
                newCroppedFileSC.append(lines[index])
                lineNum = 10000
                if lines[index].split(" ")[-2].isdigit():
                    lineNum = int(lines[index].split(" ")[-2])
                flag = False
                for index1 in range(len(lines)):
                    if ("--------------" in lines[index1])|(".asm" in lines[index1]):
                        flag = True
                        continue
                    if (flag == False):
                        continue
                    if int(lines[index1].split(" ")[-1].rstrip()) == lineNum:
                        newCroppedFileAC.append(lines[index1])
                after_num = calculate_all_tokens_num(newCroppedFileSC, newCroppedFileAC, tokenizer)
                if (before_num<=508) & (after_num>508):
                    new_SC = []
                    new_SC.append(newCroppedFileSC[0])
                    new_SC.append(newCroppedFileSC[-1])
                    newCroppedFileSC = new_SC.copy()
                    new_AC = []
                    new_AC.append(newCroppedFileAC[0])
                    flag = False
                    for index1 in range(len(lines)):
                        if ("--------------" in lines[index1])|(".asm" in lines[index1]):
                            flag = True
                            continue
                        if flag == False:
                            continue
                        if int(lines[index1].split(" ")[-1].rstrip()) == lineNum:
                            new_AC.append(lines[index1])
                    newCroppedFileAC = new_AC.copy()
                    if (before_num != 0):
                        write_cropping_file(file_name, tmpSC, tmpAC)
            # 遇到“---------” 源代码处理结束，需要写入截断文件
            else:
                if(len(newCroppedFileSC)!=1):
                    tmpSC = newCroppedFileSC.copy()
                    tmpAC = newCroppedFileAC.copy()
                    before_num = calculate_all_tokens_num(tmpSC, tmpAC, tokenizer)
                    i = 0
                    if before_num > 508:
                        while before_num>508:
                            i += 1
                            before_num = calculate_all_tokens_num(tmpSC,tmpAC[0:len(tmpAC)-i],tokenizer)
                        write_cropping_file(file_name,tmpSC,tmpAC[0:len(tmpAC)-i])
                    else:
                        write_cropping_file(file_name,tmpSC,tmpAC)
                break


if __name__ == "__main__":
    SardTokenLimited()

# 开发时间 2023/9/13 18:49
import os

from tqdm import tqdm


def division_file(file_path,file_name):
    common_lines = []
    Slines_file1 = []
    Slines_file2 = []
    Alines_file1 = []
    Alines_file2 = []
    with open(file_path,"r") as f1:
        lines = f1.readlines()
        '''common_lines: 拆分之后文件行的公共部分，即源代码第一行、分割线、汇编代码第一行信息'''
        common_lines.append(lines[0])
        count = 0
        for i in range(len(lines)):
            if '----------------' in lines[i]:
                count = i
                break
        common_lines.append(lines[count])
        common_lines.append(lines[count+1])
        '''总源代码行数 划分行数'''
        total_SC_num = count - 1
        division_num = int(total_SC_num/2 + 1)
        for i in range(1,division_num+1):
            Slines_file1.append(lines[i])
        for i in range(division_num+1,count):
            Slines_file2.append(lines[i])

        line_num = len(lines)-count-2
        print(line_num)

        for i in range(count+2,count+2+int(line_num/2)):
            Alines_file1.append(lines[i])
        for i in range(count+2+int(line_num/2),len(lines)):
            Alines_file2.append(lines[i])
        path = "D:\\Master_Project\\TData\\with_problem2\\"

        writeFile(common_lines,Slines_file1,Alines_file1,path,file_name,flag = 1)
        writeFile(common_lines,Slines_file2,Alines_file2,path,file_name,flag = 2)
    f1.close()
def writeFile(common_lines,Slines_file1,Alines_file1,path,file_name,flag):
    file_name =str(flag)+file_name
    with open(path+file_name,'w') as f:
        f.writelines(common_lines[0])
        f.writelines(Slines_file1)
        f.writelines(common_lines[1])
        f.writelines(common_lines[2])
        f.writelines(Alines_file1)
    f.close()
def division():
    path = "D:\\Master_Project\\TData\\Similar"
    files = os.listdir(path)
    for file in tqdm(files):
        print("processing:   "+ file)
        division_file(path+"\\"+file,file)
if __name__ == "__main__":
    division()
    # division_file("D:\\Master_Project\\TData\\Similar\\000120346_0.txt","000120346_0.txt")